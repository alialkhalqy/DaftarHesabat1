package com.daftar.alduyun

import android.os.Bundle
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import android.graphics.pdf.PdfDocument
import android.graphics.Paint
import android.graphics.Typeface
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.ui.platform.LocalContext
import com.daftar.alduyun.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DaftarApp() }
    }
}

class DaftarViewModel(private val dao: DaftarDao) : ViewModel() {
    val transactions = dao.transactions().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val people = dao.people().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val labels = dao.labels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTransaction(name: String, type: String, amount: Long, cost: Long, note: String,
                       personId: Long? = null, dueDate: Long? = null) {
        viewModelScope.launch {
            dao.addTransaction(TransactionEntity(
                personId = personId, personName = name, type = type,
                amount = amount, cost = cost, title = note, dueDate = dueDate
            ))
        }
    }

    fun updateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch { dao.updateTransaction(transaction) }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch { dao.deleteTransaction(id) }
    }

    fun addPerson(name: String, phone: String, type: String, note: String) {
        viewModelScope.launch { dao.addPerson(PersonEntity(name = name, phone = phone, type = type, note = note)) }
    }

    fun rename(key: String, value: String) {
        viewModelScope.launch { dao.saveLabel(LabelEntity(key, value)) }
    }

    fun seedLabels() {
        viewModelScope.launch {
            defaultLabels.forEach { if (dao.getLabel(it.key) == null) dao.saveLabel(it) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DaftarApp() {
    val context = LocalContext.current
    val dao = remember { DaftarDatabase.get(context).dao() }
    val vm = remember { DaftarViewModel(dao) }
    LaunchedEffect(Unit) { vm.seedLabels() }
    val tx by vm.transactions.collectAsState()
    val people by vm.people.collectAsState()
    val labels by vm.labels.collectAsState()
    var page by remember { mutableStateOf("الرئيسية") }
    var showAdd by remember { mutableStateOf(false) }
    val money = { n: Long -> NumberFormat.getNumberInstance(Locale("en")).format(n) + " ر.ي" }

    val cashSales = tx.filter { it.type == "SALE_CASH" }.sumOf { it.amount }
    val creditSales = tx.filter { it.type == "SALE_CREDIT" }.sumOf { it.amount }
    val customerPayments = tx.filter { it.type == "CUSTOMER_PAYMENT" }.sumOf { it.amount }
    val expenses = tx.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val supplierDebt = tx.filter { it.type == "SUPPLIER_DEBT" }.sumOf { it.amount }
    val supplierPayments = tx.filter { it.type == "SUPPLIER_PAYMENT" }.sumOf { it.amount }
    val grossProfit = tx.filter { it.type == "SALE_CASH" || it.type == "SALE_CREDIT" }
        .sumOf { (it.amount - it.cost).coerceAtLeast(0) }
    val cashBalance = cashSales + customerPayments - expenses - supplierPayments

    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF16483E),
        secondary = androidx.compose.ui.graphics.Color(0xFFC69B48),
        background = androidx.compose.ui.graphics.Color(0xFFF7F8F5)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("دفتر حسابات", fontWeight = FontWeight.Bold)
                        Text("Accounts Book · إدارة حساباتك بسهولة", style = MaterialTheme.typography.labelSmall)
                    } },
                    actions = { IconButton(onClick = { page = "الإعدادات" }) { Icon(Icons.Default.Settings, null) } }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("الرئيسية", "الزبائن", "المعاملات", "التقارير").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Icon(when(item) {
                                "الرئيسية" -> Icons.Default.Home
                                "الزبائن" -> Icons.Default.People
                                "المعاملات" -> Icons.Default.ReceiptLong
                                else -> Icons.Default.BarChart
                            }, null) },
                            label = { Text(item) }
                        )
                    }
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "إضافة معاملة")
                }
            }
        ) { padding ->
            CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
                when(page) {
                    "الرئيسية" -> HomePage(
                        Modifier.padding(padding), money(cashBalance), money(creditSales - customerPayments),
                        money(supplierDebt - supplierPayments), money(grossProfit - expenses), tx.size
                    )
                    "الزبائن" -> PeoplePage(Modifier.padding(padding), people, tx, vm, money)
                    "المعاملات" -> TransactionsPage(Modifier.padding(padding), tx, money, vm::deleteTransaction, vm::updateTransaction)
                    "التقارير" -> ReportsPage(Modifier.padding(padding), cashSales, creditSales, customerPayments, expenses, grossProfit, cashBalance, money)
                    else -> SettingsPage(Modifier.padding(padding), labels, vm)
                }
            }
        }
        if (showAdd) AddTransactionDialog(
            onDismiss = { showAdd = false },
            people = people,
            onSave = { name, type, amount, cost, note, personId, dueDate ->
                vm.addTransaction(name, type, amount, cost, note, personId, dueDate)
                showAdd = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomePage(modifier: Modifier, cash: String, customerDebt: String, supplierDebt: String, profit: String, count: Int) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            // بطاقة الهوية البصرية للتطبيق في واجهة المقدمة
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = androidx.compose.ui.graphics.Color(0xFFF0F4EF)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(68.dp),
                        shape = MaterialTheme.shapes.large,
                        color = MaterialTheme.colorScheme.primary
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.AccountBalanceWallet,
                                contentDescription = "شعار دفتر حسابات",
                                tint = androidx.compose.ui.graphics.Color(0xFFFFD77A),
                                modifier = Modifier.size(38.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            "دفتر حسابات",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Accounts Book",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            "برمجة علي حسين الخلقي",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("رصيد الصندوق التقديري", color = MaterialTheme.colorScheme.onPrimary)
                    Text(cash, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                    Text("عدد العمليات المسجلة: $count", color = MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("ديون الزبائن", customerDebt, Modifier.weight(1f))
            MetricCard("ديون الموردين", supplierDebt, Modifier.weight(1f))
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("الربح التقديري", profit, Modifier.weight(1f))
            MetricCard("حالة التخزين", "محلي", Modifier.weight(1f))
        } }
        item { Text("ابدأ من زر + لإضافة عملية بيع أو تحصيل أو مصروف أو دين مورد.", style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp)) {
        Text(title, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(8.dp))
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    people: List<PersonEntity>,
    onDismiss: () -> Unit,
    onSave: (String, String, Long, Long, String, Long?, Long?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("0") }
    var note by remember { mutableStateOf("") }
    var dueDateText by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("SALE_CASH") }
    var selectedPersonId by remember { mutableStateOf<Long?>(null) }
    var personExpanded by remember { mutableStateOf(false) }
    var typeExpanded by remember { mutableStateOf(false) }
    val types = listOf(
        "SALE_CASH" to "بيع نقدي", "SALE_CREDIT" to "بيع آجل",
        "CUSTOMER_PAYMENT" to "تحصيل من زبون", "SUPPLIER_DEBT" to "دين مورد",
        "SUPPLIER_PAYMENT" to "سداد مورد", "EXPENSE" to "مصروف",
        "INCOME" to "إيراد", "DHIMAR" to "ضمار"
    )
    val relevantPeople = when(type) {
        "SALE_CREDIT", "CUSTOMER_PAYMENT" -> people.filter { it.type == "CUSTOMER" }
        "SUPPLIER_DEBT", "SUPPLIER_PAYMENT" -> people.filter { it.type == "SUPPLIER" }
        else -> people
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة معاملة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = !typeExpanded }) {
                    OutlinedTextField(
                        value = types.first { it.first == type }.second,
                        onValueChange = {}, readOnly = true, label = { Text("نوع المعاملة") },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                        types.forEach { (key, label) -> DropdownMenuItem(text = { Text(label) }, onClick = {
                            type = key; selectedPersonId = null; name = ""; typeExpanded = false
                        }) }
                    }
                }
                if (type in listOf("SALE_CREDIT", "CUSTOMER_PAYMENT", "SUPPLIER_DEBT", "SUPPLIER_PAYMENT")) {
                    ExposedDropdownMenuBox(expanded = personExpanded, onExpandedChange = { personExpanded = !personExpanded }) {
                        OutlinedTextField(
                            value = relevantPeople.firstOrNull { it.id == selectedPersonId }?.name.orEmpty(),
                            onValueChange = {}, readOnly = true,
                            label = { Text(if (type.contains("SUPPLIER")) "اختر المورد" else "اختر الزبون") },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = personExpanded, onDismissRequest = { personExpanded = false }) {
                            relevantPeople.forEach { person ->
                                DropdownMenuItem(text = { Text(person.name) }, onClick = {
                                    selectedPersonId = person.id; name = person.name; personExpanded = false
                                })
                            }
                        }
                    }
                    if (relevantPeople.isEmpty()) {
                        Text("أضف الزبون أو المورد أولاً من قسم الزبائن.", style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    OutlinedTextField(name, { name = it }, label = { Text("الاسم / الجهة (اختياري)") }, modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالريال اليمني") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                if (type == "SALE_CASH" || type == "SALE_CREDIT") {
                    OutlinedTextField(cost, { cost = it }, label = { Text("تكلفة البضاعة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
                if (type == "SALE_CREDIT" || type == "SUPPLIER_DEBT") {
                    OutlinedTextField(dueDateText, { dueDateText = it },
                        label = { Text("موعد الاستحقاق YYYY-MM-DD (اختياري)") },
                        modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = amount.toLongOrNull() ?: 0
                val parsedDue = try {
                    if (dueDateText.isBlank()) null
                    else java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply { isLenient = false }
                        .parse(dueDateText)?.time
                } catch (_: Exception) { null }
                val needsPerson = type in listOf("SALE_CREDIT", "CUSTOMER_PAYMENT", "SUPPLIER_DEBT", "SUPPLIER_PAYMENT")
                if (a > 0 && (!needsPerson || selectedPersonId != null) &&
                    (dueDateText.isBlank() || parsedDue != null)) {
                    onSave(name, type, a, cost.toLongOrNull() ?: 0, note, selectedPersonId, parsedDue)
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun PeoplePage(
    modifier: Modifier,
    people: List<PersonEntity>,
    transactions: List<TransactionEntity>,
    vm: DaftarViewModel,
    money: (Long) -> String
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("CUSTOMER") }
    var selected by remember { mutableStateOf<PersonEntity?>(null) }

    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("إدارة الزبائن والموردين", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it }, label = { Text("اسم الشخص أو المورد") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف (اختياري)") }, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = type == "CUSTOMER", onClick = { type = "CUSTOMER" }, label = { Text("زبون") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = type == "SUPPLIER", onClick = { type = "SUPPLIER" }, label = { Text("مورد") })
            Spacer(Modifier.weight(1f))
            Button(onClick = { if (name.isNotBlank()) { vm.addPerson(name.trim(), phone.trim(), type, ""); name = ""; phone = "" } }) { Text("إضافة") }
        }
        HorizontalDivider()
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(people) { p ->
                val personTx = transactions.filter { it.personId == p.id }
                val balance = if (p.type == "CUSTOMER") {
                    personTx.filter { it.type == "SALE_CREDIT" }.sumOf { it.amount } -
                        personTx.filter { it.type == "CUSTOMER_PAYMENT" }.sumOf { it.amount }
                } else {
                    personTx.filter { it.type == "SUPPLIER_DEBT" }.sumOf { it.amount } -
                        personTx.filter { it.type == "SUPPLIER_PAYMENT" }.sumOf { it.amount }
                }
                Card(onClick = { selected = p }) {
                    ListItem(
                        headlineContent = { Text(p.name, fontWeight = FontWeight.SemiBold) },
                        supportingContent = { Text(if (p.type == "CUSTOMER") "زبون • اضغط لعرض كشف الحساب" else "مورد • اضغط لعرض كشف الحساب") },
                        leadingContent = { Icon(Icons.Default.Person, null) },
                        trailingContent = { Text(money(balance), fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }
    }
    selected?.let { person ->
        val personTx = transactions.filter { it.personId == person.id }
        val balance = if (person.type == "CUSTOMER") {
            personTx.filter { it.type == "SALE_CREDIT" }.sumOf { it.amount } -
                personTx.filter { it.type == "CUSTOMER_PAYMENT" }.sumOf { it.amount }
        } else {
            personTx.filter { it.type == "SUPPLIER_DEBT" }.sumOf { it.amount } -
                personTx.filter { it.type == "SUPPLIER_PAYMENT" }.sumOf { it.amount }
        }
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("كشف حساب: ${person.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الرصيد المتبقي: ${money(balance)}", fontWeight = FontWeight.Bold)
                    if (personTx.isEmpty()) Text("لا توجد معاملات مرتبطة بهذا الحساب.")
                    else personTx.take(12).forEach { item ->
                        Text("${item.type} — ${money(item.amount)}")
                        if (item.dueDate != null) Text("الاستحقاق: ${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(item.dueDate)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selected = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
fun TransactionsPage(
    modifier: Modifier,
    transactions: List<TransactionEntity>,
    money: (Long) -> String,
    onDelete: (Long) -> Unit,
    onUpdate: (TransactionEntity) -> Unit
) {
    var pendingDelete by remember { mutableStateOf<Long?>(null) }
    var editing by remember { mutableStateOf<TransactionEntity?>(null) }
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("سجل المعاملات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(transactions) { t ->
            Card {
                ListItem(
                    headlineContent = { Text(t.personName.ifBlank { t.title.ifBlank { "معاملة مالية" } }) },
                    supportingContent = {
                        Column {
                            Text("${transactionArabic(t.type)} • ${java.text.DateFormat.getDateTimeInstance().format(t.createdAt)}")
                            if (t.dueDate != null) Text("موعد الاستحقاق: ${java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(t.dueDate)}")
                            if (t.title.isNotBlank()) Text(t.title)
                        }
                    },
                    trailingContent = {
                        Column(horizontalAlignment = Alignment.End) {
                            Text(money(t.amount), fontWeight = FontWeight.Bold)
                            Row {
                                IconButton(onClick = { editing = t }) { Icon(Icons.Default.Edit, contentDescription = "تعديل") }
                                IconButton(onClick = { pendingDelete = t.id }) { Icon(Icons.Default.Delete, contentDescription = "حذف") }
                            }
                        }
                    }
                )
            }
        }
    }
    editing?.let { item ->
        EditTransactionDialog(item, onDismiss = { editing = null }, onSave = {
            onUpdate(it); editing = null
        })
    }
    pendingDelete?.let { id ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("حذف المعاملة؟") },
            text = { Text("سيتم حذف السجل نهائياً من قاعدة البيانات المحلية.") },
            confirmButton = { TextButton(onClick = { onDelete(id); pendingDelete = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun EditTransactionDialog(
    transaction: TransactionEntity,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var name by remember(transaction.id) { mutableStateOf(transaction.personName) }
    var amount by remember(transaction.id) { mutableStateOf(transaction.amount.toString()) }
    var cost by remember(transaction.id) { mutableStateOf(transaction.cost.toString()) }
    var note by remember(transaction.id) { mutableStateOf(transaction.title) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل المعاملة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("النوع: ${transactionArabic(transaction.type)}")
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                if (transaction.type == "SALE_CASH" || transaction.type == "SALE_CREDIT") {
                    OutlinedTextField(cost, { cost = it }, label = { Text("التكلفة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newAmount = amount.toLongOrNull()
                val newCost = cost.toLongOrNull() ?: 0
                if (newAmount != null && newAmount > 0 && newCost >= 0) {
                    onSave(transaction.copy(personName = name.trim(), amount = newAmount, cost = newCost, title = note.trim()))
                }
            }) { Text("حفظ التعديلات") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

fun transactionArabic(type: String): String = when(type) {
    "SALE_CASH" -> "بيع نقدي"
    "SALE_CREDIT" -> "بيع آجل"
    "CUSTOMER_PAYMENT" -> "تحصيل من زبون"
    "SUPPLIER_DEBT" -> "دين مورد"
    "SUPPLIER_PAYMENT" -> "سداد مورد"
    "EXPENSE" -> "مصروف"
    "INCOME" -> "إيراد"
    "DHIMAR" -> "ضمار"
    else -> type
}


fun createBackupJson(people: List<PersonEntity>, transactions: List<TransactionEntity>, labels: List<LabelEntity>): String {
    val root = JSONObject()
    root.put("format", "daftar-alduyun-backup")
    root.put("version", 1)
    root.put("createdAt", System.currentTimeMillis())
    root.put("people", JSONArray().apply {
        people.forEach { p -> put(JSONObject().apply {
            put("id", p.id); put("name", p.name); put("phone", p.phone); put("type", p.type)
            put("note", p.note); put("createdAt", p.createdAt)
        }) }
    })
    root.put("transactions", JSONArray().apply {
        transactions.forEach { t -> put(JSONObject().apply {
            put("id", t.id)
            if (t.personId == null) put("personId", JSONObject.NULL) else put("personId", t.personId)
            put("personName", t.personName); put("type", t.type); put("amount", t.amount)
            put("cost", t.cost); put("title", t.title)
            if (t.dueDate == null) put("dueDate", JSONObject.NULL) else put("dueDate", t.dueDate)
            put("createdAt", t.createdAt)
        }) }
    })
    root.put("labels", JSONArray().apply {
        labels.forEach { l -> put(JSONObject().apply { put("key", l.key); put("value", l.value) }) }
    })
    return root.toString(2)
}

fun parseBackupJson(json: String): Triple<List<PersonEntity>, List<TransactionEntity>, List<LabelEntity>> {
    val root = JSONObject(json)
    require(root.optString("format") == "daftar-alduyun-backup") { "الملف ليس نسخة احتياطية صالحة من دفتر حسابات." }
    require(root.optInt("version", -1) == 1) { "إصدار النسخة الاحتياطية غير مدعوم." }
    val pa = root.getJSONArray("people")
    val ta = root.getJSONArray("transactions")
    val la = root.getJSONArray("labels")
    val people = (0 until pa.length()).map { i ->
        val o = pa.getJSONObject(i)
        PersonEntity(o.getLong("id"), o.getString("name"), o.optString("phone"), o.getString("type"),
            o.optString("note"), o.optLong("createdAt", System.currentTimeMillis()))
    }
    val transactions = (0 until ta.length()).map { i ->
        val o = ta.getJSONObject(i)
        val pid = if (o.isNull("personId")) null else o.getLong("personId")
        val due = if (o.isNull("dueDate")) null else o.getLong("dueDate")
        TransactionEntity(o.getLong("id"), pid, o.optString("personName"), o.getString("type"),
            o.getLong("amount"), o.optLong("cost", 0), o.optString("title"), due,
            o.optLong("createdAt", System.currentTimeMillis()))
    }
    val labels = (0 until la.length()).map { i ->
        val o = la.getJSONObject(i)
        LabelEntity(o.getString("key"), o.getString("value"))
    }
    require(people.all { it.id > 0 && it.name.isNotBlank() }) { "بيانات الأشخاص في النسخة غير صحيحة." }
    require(transactions.all { it.id > 0 && it.amount >= 0 }) { "بيانات المعاملات في النسخة غير صحيحة." }
    return Triple(people, transactions, labels)
}

@Composable
fun BackupRestoreControls(dao: DaftarDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<Triple<List<PersonEntity>, List<TransactionEntity>, List<LabelEntity>>?>(null) }
    var status by remember { mutableStateOf("") }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            try {
                val json = createBackupJson(dao.allPeople(), dao.allTransactions(), dao.allLabels())
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(json) }
                    ?: error("تعذر فتح ملف الحفظ.")
                status = "تم إنشاء النسخة الاحتياطية بنجاح."
            } catch (e: Exception) { status = "فشل إنشاء النسخة: ${e.message ?: "خطأ"}" }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            try {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("تعذر قراءة الملف.")
                pending = parseBackupJson(json)
                status = "تم فحص الملف. أكد الاستعادة إذا كنت تريد استبدال البيانات."
            } catch (e: Exception) { status = "تعذر استيراد الملف: ${e.message ?: "ملف غير صالح"}" }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("النسخ الاحتياطي والاستعادة", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("الاستعادة تستبدل جميع البيانات الحالية. احتفظ بنسخة خارج الهاتف.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { saveLauncher.launch("daftar-alduyun-backup.json") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Backup, null); Spacer(Modifier.width(8.dp)); Text("إنشاء نسخة احتياطية")
        }
        OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*")) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Restore, null); Spacer(Modifier.width(8.dp)); Text("استعادة نسخة احتياطية")
        }
        if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.bodySmall)
    }
    pending?.let { data ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("تأكيد استبدال البيانات") },
            text = { Text("سيتم استبدال البيانات الحالية بـ ${data.first.size} شخص و${data.second.size} معاملة و${data.third.size} مسمى. لا يمكن التراجع عن ذلك.") },
            confirmButton = { TextButton(onClick = {
                pending = null
                scope.launch {
                    try { dao.restoreAll(data.first, data.second, data.third); status = "تمت الاستعادة بنجاح." }
                    catch (e: Exception) { status = "فشلت الاستعادة: ${e.message ?: "خطأ"}" }
                }
            }) { Text("استبدال البيانات") } },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun ReportsPage(modifier: Modifier, cashSales: Long, creditSales: Long, collections: Long, expenses: Long, grossProfit: Long, cash: Long, money: (Long) -> String) {
    val context = LocalContext.current
    val dao = remember { DaftarDatabase.get(context).dao() }
    val transactions by dao.transactions().collectAsState(initial = emptyList())
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("التقرير المالي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        ReportLine("المبيعات النقدية", money(cashSales))
        ReportLine("المبيعات الآجلة", money(creditSales))
        ReportLine("تحصيلات الزبائن", money(collections))
        ReportLine("المصروفات", money(expenses))
        ReportLine("الربح الإجمالي المسجل", money(grossProfit))
        HorizontalDivider()
        ReportLine("رصيد الصندوق التقديري", money(cash))
        Text("التقرير الحالي تجميعي لكل السجلات.", style = MaterialTheme.typography.bodySmall)
        BackupRestoreControls(dao)
        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = { exportTransactionsCsv(context, transactions) }
        ) { Icon(Icons.Default.TableView, null); Spacer(Modifier.width(8.dp)); Text("تصدير Excel-compatible CSV") }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = { exportTransactionsPdf(context, transactions) }
        ) { Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("تصدير كشف PDF") }
    }
}

fun shareExport(context: android.content.Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(context, context.packageName + ".provider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "مشاركة التقرير"))
}

fun exportTransactionsCsv(context: android.content.Context, rows: List<TransactionEntity>) {
    val file = File(context.cacheDir, "daftar_transactions.csv")
    val csv = buildString {
        appendLine("الاسم,نوع المعاملة,المبلغ,التكلفة,التاريخ,ملاحظات")
        rows.forEach { row ->
            val date = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(row.createdAt)
            val values = listOf(row.personName, transactionArabic(row.type), row.amount.toString(),
                row.cost.toString(), date, row.title)
            appendLine(values.joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
        }
    }
    file.writeText("\uFEFF" + csv, Charsets.UTF_8)
    shareExport(context, file, "text/csv")
}

fun exportTransactionsPdf(context: android.content.Context, rows: List<TransactionEntity>) {
    val pdf = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f }
    val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 18f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    var pageNumber = 1
    var page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
    var canvas = page.canvas
    var y = 48f
    canvas.drawText("Daftar AlDuyun - Transaction Report", 36f, y, titlePaint)
    y += 32f
    canvas.drawText("Name | Type | Amount | Date", 36f, y, paint)
    y += 24f
    rows.forEach { row ->
        if (y > pageHeight - 50) {
            pdf.finishPage(page)
            pageNumber++
            page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            canvas = page.canvas
            y = 48f
        }
        val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(row.createdAt)
        val line = "${row.personName.take(18)} | ${transactionArabic(row.type)} | ${row.amount} | $date"
        canvas.drawText(line.take(90), 36f, y, paint)
        y += 20f
    }
    pdf.finishPage(page)
    val file = File(context.cacheDir, "daftar_transactions.pdf")
    FileOutputStream(file).use { pdf.writeTo(it) }
    pdf.close()
    shareExport(context, file, "application/pdf")
}

@Composable
fun ReportLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SettingsPage(modifier: Modifier, labels: List<LabelEntity>, vm: DaftarViewModel) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("إعدادات التطبيق والمسميات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("يمكنك تعديل أسماء الأقسام لتناسب نشاطك التجاري. تحفظ التعديلات محلياً.", style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(labels) { label ->
                var value by remember(label.value) { mutableStateOf(label.value) }
                OutlinedTextField(
                    value = value, onValueChange = { value = it },
                    label = { Text(label.key) }, modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { if (value.isNotBlank()) vm.rename(label.key, value.trim()) }) {
                            Icon(Icons.Default.Save, contentDescription = "حفظ المسمى")
                        }
                    }
                )
            }
        }
    }
}
