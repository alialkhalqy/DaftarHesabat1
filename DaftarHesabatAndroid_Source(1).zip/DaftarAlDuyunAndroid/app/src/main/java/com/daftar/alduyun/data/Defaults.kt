package com.daftar.alduyun.data

val defaultLabels = listOf(
    LabelEntity("customers", "ديون الزبائن"),
    LabelEntity("suppliers", "ديون الموردين"),
    LabelEntity("cash_sales", "المبيعات النقدية"),
    LabelEntity("credit_sales", "المبيعات الآجلة"),
    LabelEntity("expenses", "المصروفات"),
    LabelEntity("income", "الإيرادات"),
    LabelEntity("dhimar", "الضمار"),
    LabelEntity("payments", "التحصيلات")
)
